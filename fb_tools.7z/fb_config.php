<?php if(!defined('fb_tools')) die("Preset-File for fb_tools"); // (charset=ascii / tabs=8 / lines=cr+lf / lang=de)

 if(!isset($cfg['preset'])) $cfg['preset'] = array();	// cfg[preset] Anlegen, wenn es nicht existiert
 $cfg['preset'] += array(               # begin (Fritz!Box Zugangsdaten)
// # Example begin
  'fbstd'    => 'http://192.168.178.1',           # Standart-IP
  'fbata'    => array('host' => '192.168.188.1'), # Standart-IP (ATA-Modus)
  'notfall'  => array('host' => '169.254.1.1'),   # ZeroConf-IP (Ohne DHCP)
  'beispiel' => array('host' => 'fritz.box', 'pass' => 'geheim'), # Klassisch nur Kennwort
  'myfritz'  => array(	'sock' => 'https',
			'host' => '0123456789abcdef.myfritz.net',
			'port' => 443,
			'user' => 'admin',
			'pass' => 'admin123',
			'uipw' => 'GOOG LETW OFAC TORA UTHE NTIC ATIO NOTP'),
  'shorty' => 'https://admin:admin123@0123456789abcdef.myfritz.net:65443#GOOGLETWOFACTORAUTHENTICATIONOTP',
  '7456' => json2array($cfg['zlib']['inflate'](base64_decode('q87ILy6xUsrIz03Vy03NS0/NyU7VS0lV0inILyqxsjCwMNApSCwutlIKTi0uzszP83RRqgUA'))),
// # Example end

/* # Example begin
  'meinebox' => array(
    'sock' => 'http',                   # -p  : Protokoll (auto, http, https, ssl, tls)
    'host' => 'fritz.nas',              # -fb : IP/DNS-Adresse der Fritz!Box
    'port' => 80,                       # -pt : Port (http -> 80, https -> 443)
    'user' => 'max',                    # -un : Benutzername (Oder auch false, bei automatisch erstellter Benutzer - z.B. fritz1337)
    'pass' => str_rot13('xraajbeg'),    # -pw : Kennwort (Pseudo-Schutz mit Rot13)
    'uipw' => false,                    # -ui : OS4 Anmelde-Kennwort bei Fernwartung ODER Ab OS6.80+ Zwei-Faktor-Authentisierung (NUR wenn erforderlich)
    'totp' => false,                    # -tf : OS6.80+ Zwei-Faktor-Authentisierung bei Login (ABCD EFGH IJKL MNOP QRST UVWX YZ23 4567)
    'livs' => 0,                        # -li : Login-Version (0 -> Auto, 1 -> MD5, 2 -> PBKDF2)
  ),
*/ # Example end

 );                                     # end (Fritz!Box Zugangsdaten)

 $cfg['drag'] = array(			# Drag'n'Drop-Modus
  '*'	=> 'info hash *',		# Fuer Unbekannte Dateitypen
  'csv'	=> 'info csv *',
  'txt'	=> 'info cat *',
  'json'=> 'info json *',
  'tar'	=> 'info extrakt *',
  'tbz'	=> 'info extrakt *',
  'tgz'	=> 'info extrakt *',
  'zip'	=> 'info extrakt *',
  'export' => 'konfig fcs * -d',
 );

 $cfg['plugin'] = array(                # Plugin Voreinstellungen

/* # Example begin
  'sqldb' => array(                     # SQLDB Plugin begin
    'preset' => array(

      'mydb' => array(
        'type' => 'mysqli',
        'host' => 'localhost',
        'port' => 3306,
        'user' => 'root',
        'pass' => '',
        'base' => 'fb_tools'),

      'lite' => array(
        'type' => 'sqlite3',
        'file' => '/usr/local/share/fb_tools/sqlite.db',
      )
    )
  ),                                    # SQLDB Plugin end

  'juis-update' => array(		# JUIS-Update Plugin
    'sn' => '/path/.sndb.json.gz',
  ),

  'serial' => array(			# Serial Plugin
    'sn' => '/path/.sndb.json.gz',
  ),

*/ # Example end

 );                                     # ENDE der Plugin Voreinstellungen

# $cfg['cron'] = true;                  # Fuer Cron-Dienste (Individuelle Einstellungen mit $cfg['pscm'])

// Fuer Exotische Terminals
# $cfg['wrap'] = 0;                     # Automatischer Zeilenumbruch deaktivieren
# $cfg['char'] = 'iso-8859-1';          # Standart-Charset
# $cfg['upda'] = $cfg['uplink'] = 0;    # Keine Updates und keinen Update-Check

# dbug($cfg);                           # Vorhandene Einstellungen mit "-d" anzeigen

?>
