<?php if(!defined('fb_tools')) die("Plugin-File for fb_tools");	// (charset=iso-8859-1 / tabs=8 / lines=lf / lang=de)

 $plugin = "KonfigPatcher 0.01 (c) 01.12.2022 by Michael Engelke";
 $info = 'Universalpatcher f�r die Konfiguration';
 $meta = '{"fbt":0.32}'; /*

Plugingeschichte:
0.01 01.12.2022
 - Erste Version
*/
 $patches = json2array('{
  Base2Bin: {
	m: "convert",
	p: /^(?P<base2bin>\*{4} B64FILE:.*\s*)([\w+\/\s=]*?)(?=\s*\*{4} END OF FILE \*{4})/im,
	i: "Convertiert Base64 Container in Binaer"},
  Bin2Base: {
	m: "convert",
	p: /^(?P<bin2base>\*{4} BINFILE:.*\s*)([\dA-F\s]*?)(?=\s*\*{4} END OF FILE \*{4})/im,
	i: "Convertiert Binaer Container in Base64"},
  "GUI-Protect": {
	m: "bool",
	p: /((_hidden|gui_readonly) = )(yes|no)(?=;\s*$)/im,
	r: ["$1no","$1yes"],
	i: "(Ent)sperrt Konfigbereiche der Fritz!Box"},
  LED: {
	m: "bool",
	p: /^(\s{8}control = led_)(on|off)(?=;\s*$)/m,
	r: ["$1off","$1on"],
	i: "Schaltet die LED-L�uchten an oder aus"},
  TwoFactor: {
	m: "bool",
	p: /^(\s{8}two_factor_auth_enabled = )(yes|no)(?=;\s*$)/m,
	r: ["$1no","$1yes"],
	i: "(De)aktiviert die Zwei-Faktor-Authentisierung"},
  "VOIP-Protect": {
	m: "bool",
	p: /(((ata|voip_2ndPVC)_hidden|gui_readonly) = )(yes|no)(?=;\s*$)/im,
	r: ["$1no","$1yes"],
	i: "(Ent)sperrt die VoIP-Einstellungen der Fritz!Box"},
  "WANMAC-Override": {
	m: "set",
	p: /(enable_mac_override = )(no|yes)/,
	r: "$1yes",
	f: /(?<=macdsl_override = )[\w:]+/,
	s: /^[\da-z]{2}(:[\da-z]{2}){5}$/i,
	a: "[set:mac]",
	i: "�berschreibt die WAN-MAC-Adresse mit einer beliebigen anderen MAC-Adresse"},
 }');
 function patchKonfig($data,$patch=false,$cmd=false) {			// Patch Data
  if(is_array($data)) {							// Callback Patch
   if(isset($data['base2bin']))
    $data = str_replace('64','IN',$data[1]).wordwrap(bin2hex(base64_decode($data[2])),80,"\n",true);
   elseif(isset($data['bin2base']))
    $data = str_replace('IN','64',$data[1]).wordwrap(base64_encode(pack('H*',preg_replace('/[^\da-f]+/i','',$data[2]))),80,"\n",true);
   else
    $data = "";
   return $data;
  }
  else {								// Normaler aufruf
   $count = 0;
   if($patch['m'] == 'bool' and is_int($cmd))
    $new = preg_replace($patch['p'],$patch['r'][$cmd],$data,($c = ifset($patch['c'])) ? $c : -1,$count);
   elseif($patch['m'] == 'set' and $cmd and preg_match($patch['s'],$cmd))
    $new = preg_replace($patch['f'],'${1}'.$cmd,
	preg_replace($patch['p'],$patch['r'],$data),
	($c = ifset($patch['c'])) ? $c : -1,$count);
   elseif($patch['m'] == 'convert')
    $new = preg_replace_callback($patch['p'],__FUNCTION__,$data,($c = ifset($patch['c'])) ? $c : -1,$count);
   return ($count and $new != $data) ? $new : false;
  }
 }
 if(ifset($cfg['help']) or !getArg(true)) {				// Hilfe Ausgeben
  $out = "";
  foreach($patches as $key => $var)
   $out .= strtolower($key)."|".(isset($var['a']) ? $var['a'] : (($var['m'] == 'bool') ? '[cmd:on\|off]' : ""))."|$var[i]\n";
  out("$plugin\n$info\n\n$self <fritz.box> <PlugIn> [plug:$plug] [patch] <cmd:off|on> <set> <file> <save>\n
Patches (patch):\n{{{tt}$out}}"
  .((ifset($cfg['help'],'/[ab]/i')) ? "\n\nBeispiel:\n$self fritz.box $plug patch:led cmd:off
$self $plug voip off file:konfig.export save:konfig_patch.export
$self fritz.box $plug base2bin" : ""));
  if(!$cfg['help'] or $cfg['help'] === true)
   $cfg['help'] = -1;
  $opts .= "KonfigPatcher:|-rd:|<path\|file>|Erstellt ein Backup von der Konfig-Datei";
 }
 elseif($patch = getArg('patch','/^[\w-]+$/0')) {			// Parameter �berpr�fen
  $cmd = ($cmd = getArg('cmd','/^(?:(off|aus)|(on|an))($)/i')) ? ($cmd[2] ? 1 : 0) : getArg('set','/^[\w:.-]+$/0');
  if($patch = preg_array("/$patch/i",$patches,1) and (!ifset($patch['m'],'/^(bool|set)$/') or $cmd !== false)) {
   if($file = getArg('file','file_exists') and $data = file_contents($file)) {// Konfig offline patchen
    dbug("Patche Konfigurations-File");					// Debug-Meldung f�r preg_replace
    if($data = patchKonfig($data,$patch,$cmd))				// Auf �nderung pr�fen
     file_contents(($save = getArg('save')) ? $save : $file,cfgcalcsum($data));
    else
     out("Keine �nderungen vorgenommen");
   }
   elseif($sid = (ifset($cfg['bsid'])) ? $cfg['bsid'] : login(0,0,true)) {// Login mit 2FA durchf�hren
    if($cfg['bsid'] or $cfg['fiwa'] < 530 or isset($cfg['auth']['BoxAdmin'])) {
     dbug("Hole Konfiguration");					// Debug-Meldung f�r cfgexport
     $data = cfgexport(false,$cfg['pass']);				// Konfig aus der Fritz!Box holen
     if($file = getArg('-rd'))						// RAW-Daten Speichern
      saverpdata($file,$data,"konfig.export");
     dbug("Patche Konfiguration");					// Debug-Meldung f�r preg_replace
     if($data = patchKonfig($data,$patch,$cmd)) {			// Auf �nderung pr�fen
      if($cfg['dbug']/(1<<0)%2)						// Debug-Meldung f�r cfgimport
       dbug("Sende Konfiguration");
      out((cfgimport(false,$cfg['pass'],$data))				// Importieren
       ? "Konfig wurde hochgeladen und wird nun bearbeitet" : errmsg(0,'cfgimport'));	// R�ckmeldung
     }
     else
      out("Keine �nderungen vorgenommen");
    }
    else
     out(errmsg("8:Benutzer hat nicht das Recht f�r die Administration"));
    if(!ifset($cfg['bsid']))						// Abmelden (Eigentlich Unn�tig)
     logout($sid);
   }
   else
    out(errmsg(0,'login'));						// Login fehlgeschlagen
  }
  else
   out(errmsg("2:Patch nicht gefunden oder Parameter passen nicht zum ausgew�hlten Patch"));
 }
 else
  out(errmsg("2:Parameter m�ssen korrekt angegeben werden"));

?>
