<?php if(!defined('fb_tools')) die("Plugin-File for fb_tools");	// (charset=iso-8859-1 / tabs=8 / lines=lf / lang=de)

 $plugin = "2FA 0.02 (c) 06.01.2024 by Michael Engelke";
 $info = '(De-)aktiviert die Zwei-Faktor-Authentisierung';
 $meta = '{"fbt":0.40, "fos":6.68}'; /*

Plugingeschichte:
0.01 28.12.2023
 - Erste Version
0.02 06.01.2024
 - Pr�fung ob 2FA unterst�tzt wird
*/
 if(ifset($cfg['help']) or !getArg(true))			// Hilfe Ausgeben bei -h oder ohne Parameter
  out("$plugin\n$info\n\n$self <PlugIn> [plug:$plug] [func:an|aus|off|on|test]".(ifset($cfg['help'],'/[ab]/i') ? "\n
Beispiele:\n$self $plug aus\n$self $plug test" : "")."\n");

 elseif($arg = getArg('func') and $arg = ifset($arg,'/^(?:(an|on)|(aus|off)|(test))($)/')) { // 'func'-Parameter �berpr�fen
  login(false);
  if(ifset($cfg['boxinfo']['Name'],'/^FRITZ!Box\b/i')) {
   $var = is_array($flag = $cfg['boxinfo']['Flag']) ? preg_array('/^2nd_factor_disabled$/i',$flag) : false;
   if(ifset($arg[3]) or $arg[1] and !$var or $arg[2] and $var)
    out($var ? errmsg("1:2FA ist deaktiviert") : "2FA ist aktiv");	// 2FA-Status ausgeben
   else {
    $request = "xhr=1&page=support&twofactor=1".(ifset($arg[1]) ? "&twofactor_auth_enabled=on" : "")."&sid=";
    out((ifset($arg[1]) ? "A" : "Dea")."ktiviere die Zwei-Faktor-Authentisierung");
    if($sid = (ifset($arg[1]) ? login() : login(0,0,true))) {
     dbug("Sende den 2FA-Befehl");
     request('post',"/data.lua",$request.$sid);
     if(!ifset($cfg['bsid']))
      logout($sid);
    }
    else
     out(errmsg(0,'login'));
   }
  }
  else
   out(errmsg("8:2FA wird nicht unterst�tzt"));
 }
 else								// 'func'-Parameter fehlt
  out(errmsg("2:Fehler: Parameter func nicht �bergeben!"));	// Fehlermeldung

?>
