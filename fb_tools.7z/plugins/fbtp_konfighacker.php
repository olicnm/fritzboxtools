<?php if(!defined('fb_tools')) die("Plugin-File for fb_tools");	// (charset=iso-8859-1 / tabs=8 / lines=lf / lang=de)

 $plugin = "KonfigHacker 0.05 (c) 27.12.2023 by Michael Engelke";
 $info = 'Konfig-Key per Bruteforce knacken';
 $meta = '{"fbt":0.30 "ssl":0.9}'; /*

Plugingeschichte:
0.00 16.09.2019
 - Erste Test-Version (POC)
 - Danke an SM vom CERN (Unm�glich ist es erst, wenn es bewiesen wurde)
0.01 22.09.2019
 - Erste vollst�ndige Version
0.02 05.11.2020
 - Unterst�tzung f�r BZip Dateien
 - Unterst�tzung von Arrays in Optionen
 - Ben�tigt zwingend fb_Tools 0.28+
0.03 23.03.2021
 - AVM MAC-Adressen erweitert
 - Anpassung an fb_Tools 0.30+
0.04 01.12.2022
 - AVM MAC-Adressen erweitert
 - Minimale Optimierungen vorgenommen
 - Das auffinden von alten MAC-Adressen etwas beschleunigt
0.05 27.12.2023
 - BUG: Im MAC-Modus funktionierte die Fortschrittsanzeige nicht
*/
 if(ifset($cfg['help']) or !getArg(true)) {			// Hilfe Ausgeben bei -h oder ohne Parameter
  out("$plugin\n$info\n\n$self <PlugIn> [plug:$plug] [crypt] <pass> <mac> <serial>"
	.((ifset($cfg['help'],'/[ab]/i') and $base = str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ123456')) ? "\n
Beispiele:
$self $plug $base
$self $plug crypt:$$$\$$base mac:11:23:58
$self $plug crypt:$base mac[/]:11:23:58/13:21:34
$self $plug crypt:$base serial:A123.456.78.901.234
$self $plug crypt:$$$\$$base pass:passwd.txt
$self $plug crypt:$base pass[,]:admin,123456,password,qwertz,12345
$self $plug crypt:$base pass[!]:passwd.txt!kennwort.txt" : "")."\n");
  if(!$cfg['help'] or $cfg['help'] === true)
   $cfg['help'] = -1;
  $opts .= "KonfigHacker:|-sa||Auch bei einem erfolgreichen Fund weiter suchen";
 }
 elseif($data = getArg('crypt','/^(\${4})?([A-Z1-6]{32,})$/2')) {// 'crypt'-Parameter �berpr�fen
  $pass = getArg('pass',array());
  $macs = ($var = getArg('mac',array())) ? $var : ((preg_match_all('/[\dA-F]{6}/',
	strtoupper(bin2hex(base64_decode("AAQOABUMABpPABxKAB8/ACT+vAVDwCUGJGURnMemCJbXNDHENIHEXEl5yA4UOBDV4ChtzM4eRE5t6N9wfP9N8LAUmJvL3DlvLDr9LJGrPKYvdEJ/0BLL3BXIPDcSHO1vsPIIUOY2SF01"))),$avm))
	? preg_replace('/../','$0:',$avm[0]) : 0);
  $serial = ($var = getArg('serial','/([A-Z](?:0[1-9]|[1-4]\d|5[0-3])[1-7]\.?\d{3}\.?\d{2}(?:\.?\d{3}){2})/1'))
	? str_replace('.','',$var) : str_repeat('0',16);
  $iv = substr($d = unBase($data),0,16);			// AES iv
  $data = substr($d,16).str_repeat("\0",16 - strlen($d) % 16);	// AES data.pad
  $pad = str_repeat("\0",16);					// Pad f�r Key
  $secret = $key = false;
  dbug("AES-IV:     ".bin2hex($iv)."\nAES-Cipher: ".bin2hex(substr($d,16)));
  if($pass) {							// Kennw�rter durchprobieren
   $a = $b = 0;
   $c = microtime(true);					// Startzeit Stoppen
   foreach($pass as $file) {
    if($fp = (file_exists($file)) ? file_stream($file) : false)	// Passwordliste �ffnen (<r4<k5747!0n.n37)
     dbug("Lese Password-Liste: $file");
    while($pwd = $fp ? file_stream($fp) : (($var = $file and !$file = false) ? $var : $file)
	and !($key = openssl_decrypt($data, "AES-256-CBC",
	hash('md5',str_replace(array("\r","\n"),'',$pwd),true).$pad, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING, $iv)
	and substr($key,4,2) == "\0\0"
	and hexdec(bin2hex(substr($key,4,4))) < strlen($key)	// pack("A4",substr($key,4,4))
	and substr(hash('md5',substr($key,4,strlen($key) - 20),true),0,4) == substr($key,0,4)))
     if($a++ == 1e6) {
      out(".",10);
      $b += $a;
      $a = 0;
     }
    if($fp)
     out("\n",8);
    if($pwd) {
     $aes = preg_replace('/[\r\n]+/','',$pwd);
     $secret = "Kennwort gefunden: $aes";
     $aes = hash('md5',$aes,true).$pad;
     if(!getArg('-sa')) {
      $speed = ($all = $a + $b) / ($time = microtime(true) - $c);// Endzeit Stoppen
      break;
     }
     else {
      dbug("AES-Key:    ".bin2hex($aes));
      out($secret);
      $secret = $aes = "";
     }
    }
   }
  }
  else {							// Mac-Adressen durchprobieren
   for($a=$all=$time=0, $hex=array(); $a < 256; $hex[] = strtoupper(str_pad(dechex($a++),2,0,STR_PAD_LEFT)));
   foreach($macs as $mac)					// Alle MAC-Hersteller durchgehen
    if(preg_match('/^([\da-f]{2}([:-]|$)){3}/i',$mac,$var)) {
     $mac = strtoupper(preg_replace('/\W+|(?<=\w)$/',':',$var[0]));
     $a = $b = $c = $d = $e = 0;				// MAC-Nummern Initialisieren
     out($f = "Versuche $mac",10);
     $f = strlen($f);
     $g = microtime(true);					// Startzeit Stoppen
     while(!($key = openssl_decrypt($data, "AES-256-CBC",
	hash('md5',"$serial\n$mac".$hex[$c].":".$hex[$b].":".$hex[$a]."\n",true).$pad, OPENSSL_RAW_DATA | OPENSSL_ZERO_PADDING, $iv)
	and substr($key,4,2) == "\0\0"
	and hexdec(bin2hex(substr($key,4,4))) < strlen($key)	// pack("A4",substr($key,4,4))
	and substr(hash('md5',substr($key,4,strlen($key) - 20),true),0,4) == substr($key,0,4)))
      if(!($a = ++$a & 255))
       if(!($b = ++$b & 255)) {
        $e = floor(($c / 256) * max($cfg['wrap']-$f,10)) - $d;	// Fortschrittsanzeige
        out(str_repeat(".",$e),10);
        $d += $e;
        if(!($c = ++$c & 255))
         break;
       }
     out("\n",8);
     $time += microtime(true) - $g;				// Endzeit Stoppen
     if($a + $b + $c > 0) {
      $aes = $mac.$hex[$c].":".$hex[$b].":".$hex[$a];
      $secret = "MAC-Adresse gefunden: $aes";
      $aes = hash('md5',"$serial\n$aes\n",true).$pad;
      if(!getArg('-sa')) {
       $all += $a + $b * 256 + $c * 65536;
       $speed = $all / $time;
       break;
      }
      else {
       dbug("AES-Key:    ".bin2hex($aes));
       out($secret);
       $secret = $aes = "";
      }
     }
     else
      $all += 1<<24;
    }
  }
  if($secret and $key) {
   $var = substr($key,8,hexdec(bin2hex(substr($key,4,4))));
   dbug("AES-Key:    ".bin2hex($aes)."\nAES-Decrypt:".bin2hex(substr($key,0,4))." ".bin2hex(substr($key,4,4))." ".bin2hex($var));
   if(substr($var,0,strlen($var)/2) == substr($var,strlen($var)/2))
    dbug("Konfig-Key: ".bin2hex(substr($var,strlen($var)/2).$pad));
   elseif(preg_match('/^([[:print:]]+)\0?$/',$var,$val))
    dbug("Decrypted:  $val[1]");
  }
  else {
   $secret = "Nichts gefunden, keine Entschl�sselung m�glich!";
   if(!isset($all))
    $all = $a + $b;
   if(!isset($time))
    $time = microtime(true) - $c;
   if(!isset($speed))
    $speed = $all / $time;
  }
  dbug(number_format($speed,0,0,'.')." Versuche in der Sekunde von insgesamt ".number_format($all,0,0,'.')." Versuchen in ".gmdate('H:i:s',floor($time)));
  out($secret);
 }
 else								// 'crypt'-Parameter fehlt
  out(errmsg("2:Fehler: Parameter crypt nicht �bergeben!"));	// Fehlermeldung

?>
