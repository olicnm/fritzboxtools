<?php if(!defined('fb_tools')) die("Plugin-File for fb_tools");	// (charset=iso-8859-1 / tabs=8 / lines=lf / lang=de)

 $plugin = "Test 0.00 (c) 00.00.0000 by Michael Engelke";
 $info = 'Test-Plugin';
 $meta = '{"fbt":0.32}'; /*

Plugingeschichte:
0.00 00.00.0000
 - Erste Version
*/
 if(ifset($cfg['help']) or !getArg(true))			// Hilfe Ausgeben bei -h oder ohne Parameter
  out("$plugin\n$info\n\n$self <PlugIn> [plug:$plug] [test:String]".(ifset($cfg['help'],'/[ab]/i') ? "\n
Beispiele:\n$self $plug test:{$qt}Foo Bar$qt" : "")."\n");

 elseif($arg = getArg('test')) {				// 'test'-Parameter �berpr�fen

  out($arg);							// Parameter ausgeben

 }
 else								// 'test'-Parameter fehlt
  out(errmsg("2:Fehler: Parameter test nicht �bergeben!"));	// Fehlermeldung

?>
