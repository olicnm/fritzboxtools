<?php if(!defined('fb_tools')) die("Plugin-File for fb_tools");	// (charset=iso-8859-1 / tabs=8 / lines=lf / lang=de)

 $plugin = "Neustart 0.04 (c) 01.12.2022 by Michael Engelke";
 $info = 'Startet die Fritz!Box neu! (Web-Variante)';
 $meta = '{"fbt":0.32}';  /*

Plugingeschichte:
0.01 23.05.2018
 - Erste Version
0.02 21.08.2019
 - Unterst�tzung f�r Fritz!OS 5.x - 7.1
0.03 05.10.2020
 - Unterst�tzung f�r Fritz!OS 4.x
0.04 01.12.2022
 - Anpassung an fb_Tools 0.32+
*/
 if(ifset($cfg['help'])) {						// Hilfe Ausgeben
  out("$plugin\n$info\n\n$self [fritz.box] Plugin $plug"
  .((ifset($cfg['help'],'/[ab]/i')) ? "\n\nBeispiel:\n$self fritz.box plugin $plug\n\n" : ""));
 }
 elseif($sid = (ifset($cfg['bsid'])) ? $cfg['bsid'] : login()) {	// Login durchf�hren
  if($cfg['bsid'] or $cfg['fiwa'] < 530 or isset($cfg['auth']['BoxAdmin'])) {
   out("Starte $cfg[host] neu");						// Kurze Mitteilung
   $s = "&sid=$sid";
   if($cfg['fiwa'] >= 708) {
    dbug("Neustart-Variante f�r Fritz!OS 7.1+");
    request('POST','/data.lua',"xhr=1&no_sidrenew=&reboot=&oldpage=%2Fsystem%2Freboot.lua$s");		// Reset ank�ndigen
    request('POST','/reboot.lua',"ajax=1&no_sidrenew=1&xhr=1&useajax=1$s");				// und best�tigen
   }
   elseif($cfg['fiwa'] >= 650) {
    dbug("Neustart-Variante f�r Fritz!OS 6.5 - 7.0");
    request('POST','/data.lua',"xhr=1&lang=de&no_sidrenew=&reboot=&oldpage=%2Fsystem%2Freboot.lua$s");	// Reset ank�ndigen
    request('GET','/reboot.lua',"ajax=1&no_sidrenew=1&xhr=1$s");						// und best�tigen
   }
   else {
    dbug("Neustart-Variante f�r Fritz!OS 4.x - 6.3");
    request('POST','/system/reboot.lua',"reboot=$s");			// Reset ank�ndigen
    request('GET','/reboot.lua',"ajax=1&xhr=1$s");			// und best�tigen
    request('POST','/cgi-bin/webcm',strtr("getpage=../html/reboot.html&logic:command/reboot=../gateway/commands/saveconfig.html$s",array('/' => '%2F', ':' => '%3A')));	// F�r OS 4.x
   }
  }
  else
   out(errmsg("8:Benutzer hat nicht das Recht f�r die Administration"));
  if(!ifset($cfg['bsid']))						// Abmelden
   logout($sid);
 }
 else
  out(errmsg(0,'login'));						// Login fehlgeschlagen

?>
